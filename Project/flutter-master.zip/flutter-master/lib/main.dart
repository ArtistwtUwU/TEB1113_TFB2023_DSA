import 'package:flutter/material.dart';
import 'ffi/sort_ffi.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter/services.dart';


void main() => runApp(SortApp());

class SortApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter + C++ Sort',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'Poppins', primarySwatch: Colors.blue),
      home: SortHome(),
    );
  }
}

class SortHome extends StatefulWidget {
  @override
  _SortHomeState createState() => _SortHomeState();
}

class _SortHomeState extends State<SortHome> {
  final TextEditingController controller = TextEditingController();
  List<int> bubble = [];
  List<int> merge = [];
  int stepsBubble = 0;
  int stepsMerge = 0;
  int timeBubble = 0;
  int timeMerge = 0;

  Future<void> sortData() async {
    final input = controller.text.split(',').map((e) => int.tryParse(e.trim()) ?? 0).toList();

    final bubbleWatch = Stopwatch()..start();
    final bubbleResult = await runSort(List.from(input), true);
    bubbleWatch.stop();

    final mergeWatch = Stopwatch()..start();
    final mergeResult = await runSort(List.from(input), false);
    mergeWatch.stop();

    setState(() {
      bubble = bubbleResult["sorted"];
      merge = mergeResult["sorted"];
      stepsBubble = bubbleResult["steps"];
      stepsMerge = mergeResult["steps"];
      timeBubble = bubbleWatch.elapsedMilliseconds;
      timeMerge = mergeWatch.elapsedMilliseconds;
    });
  }

  Widget result(String label, List<int> arr, int steps, int time){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '$label (Steps: $steps, Time: ${time}ms)',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        Wrap(
          children: arr.map((e) =>
              Container(
                margin: EdgeInsets.all(4),
                width: 45,
                height: 45,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withAlpha(30),
                      blurRadius: 6,
                      offset: Offset(2, 3),
                    )
                  ],
                ),
                child: Center(
                  child: Text(
                    e.toString(),
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              )
          ).toList(),
        ),
      ],
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: appBar(),
      body: Column(
          children: [
            _searchField(),
            SizedBox(height: 40),
            _buttonOutput(),
            SizedBox(height: 40),
            result("Bubble Sort", bubble, stepsBubble, timeBubble),

            SizedBox(height: 40),
            result("Merge Sort", merge, stepsMerge, timeMerge),
          ]
      ),
    );
  }

  ElevatedButton _buttonOutput() {
    return ElevatedButton(
        onPressed: sortData,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 4,
          padding: EdgeInsets.symmetric(horizontal: 32, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15)
          )
        ),
        child: Text("Sort"),
    );
}

  Container _searchField(){
    return Container(
      margin: EdgeInsets.only(top: 40, left: 20, right: 20),
      decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
                color: Color(0xff1D1617).withAlpha(28),
                blurRadius: 40,
                spreadRadius: 0.0
            )
          ]
      ),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            labelText: "Enter Numbers (Comma-separated)",
            contentPadding: EdgeInsets.all(15),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide.none
            )
        ),
      ),
    );
  }

  AppBar appBar() {
    return AppBar(
      title: Text(
        "SortDuel",
        style: TextStyle(
          color: Colors.black,
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      backgroundColor: Colors.white,
      elevation: 0.0,
      centerTitle: true,
      leading: GestureDetector(
        onTap: () {
          SystemNavigator.pop();
        },
        child: Container(
          margin: EdgeInsets.all(10),
          alignment: Alignment.center,
          decoration: BoxDecoration(
              color: Color(0xffF7F8F8),
              borderRadius: BorderRadius.circular(10)
          ),
          child: SvgPicture.asset(
            'assets/left_arrow.svg',
            width: 20,
            height: 20,
          ),
        ),
      ),
    );
  }
}